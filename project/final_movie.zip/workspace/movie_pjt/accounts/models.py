from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings
from movies.models import *
# Create your models here.



class User(AbstractUser):
    # like_directors = models.ManyToManyField(Director, related_name='directors', blank=True)
    followers = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='followings')
    like_actors = models.ManyToManyField(Actor, related_name='actors', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    nickname = models.CharField(max_length=40, blank=True)
    introduction = models.TextField(blank=True)
    my_genres = models.ManyToManyField(Genre, related_name='genres', blank=True)
    my_movies = models.ManyToManyField(Comment, related_name='movies', blank=True)
    like_directors = models.ManyToManyField(Director, related_name='directors', blank=True)