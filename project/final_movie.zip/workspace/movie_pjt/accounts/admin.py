from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import *



admin.site.register(User, UserAdmin)
# # Register your models here.


class ProfileAdmin(admin.ModelAdmin):
    list_display = ['nickname', 'introduction', 'user_id']
admin.site.register(Profile, ProfileAdmin)