from django.urls import path
from . import views

app_name = 'accounts'

urlpatterns = [
    # path('movies/<int:user_pk>/follow/', views.follow_movie, name='follow_movie'),
    path('profile/update/', views.profile_update, name='profile_update'),
    ##### 장르선택
    path('follow/<int:user_pk>/', views.follow, name='follow'),
    path('genre/<int:user_pk>/', views.select_genre, name='select_genre'),
    path('password/', views.password, name='password'),
    path('delete/', views.delete, name='delete'),
    path('update/', views.update, name='update'),
    path('logout/', views.logout, name='logout'),
    path('login/', views.login, name='login'),
    path('signup/', views.signup, name='signup'),
]