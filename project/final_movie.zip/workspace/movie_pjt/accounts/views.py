import random
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, PasswordChangeForm
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.contrib.auth import update_session_auth_hash
from .forms import CustomUserChangeForm, CustomUserCreationForm, ProfileForm
from .models import Profile
from movies.models import Genre, Movie

# Create your views here.
############################ signup ################################

    
def signup(request):
    
    if request.user.is_authenticated:
        return redirect('movies:list')
      
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            Profile.objects.create(user=user)	
            auth_login(request, user) 				
            return redirect('accounts:select_genre', user.pk)
    else:
        form = CustomUserCreationForm()
    context = {'form': form,
       }
    return render(request, 'accbueno/signup.html', context)
    

######################        SELECT_GENRE     #########################
@login_required
def select_genre(request, user_pk):
    profile = get_object_or_404(Profile, user_id=user_pk)
    genres = Genre.objects.all()
    movies = Movie.objects.all()
    if request.method == 'POST':
        for genre in request.POST.getlist('genre'):
            profile.my_genres.add(genre)
        return redirect('movies:list')

    context = {
        'genres': genres,
        'profile':profile,
        'movies':movies,
    }
    return render(request, 'accounts/select_genre.html', context)
    
            
########################### login ####################################
def login(request):
    if request.user.is_authenticated:
        return redirect('movies:list')
    
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            auth_login(request, form.get_user())
            return redirect(request.GET.get('next') or 'movies:list') # 해당 코드 수정
    else:
        form = AuthenticationForm()
    context = {'form': form}
    return render(request, 'accounts/login.html', context)
    
    
    
############logout ####################


def logout(request):
    auth_logout(request)
    return redirect('movies:list')
    

#################### profile my page ################
def people(request, username):
    people = get_object_or_404(get_user_model(), username=username)
    movies = Movie.objects.all()
    movie = random.choice(movies)
    
    genre_pick = random.choice(range(1, 17))
    
    movie_set = []
    
    for genre in people.profile.my_genres.all():
        movie_set.append(Movie.objects.filter(genres__id=genre.pk).order_by('pk'))
        
    if movie_set:
        my_movies = random.choice(movie_set)
    else:
        my_movies = Movie.objects.filter(genres__id=genre_pick).order_by('pk')
    
    
    context = {
        'people': people,
        'my_movies': my_movies,
        'movie': movie,
    }
    return render(request, 'accbueno/people.html', context)




###### 회원정보 수정 및 탈퇴 ###############3
@login_required
def update(request):
    if request.method == 'POST':
        user_change_form = CustomUserChangeForm(request.POST, instance=request.user)
        if user_change_form.is_valid():
            user = user_change_form.save()
            return redirect('people', request.user.username)
    else:
        user_change_form = CustomUserChangeForm(instance=request.user)

    context = {'user_change_form': user_change_form}
    return render(request, 'accounts/update.html', context)


@login_required
def delete(request):
    if request.method == 'POST':
        request.user.delete()
    return redirect('movies:list')

    
############################# 비밀번호 변경 #########################
@login_required
def password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            return redirect('movies:list')
    else:
        form = PasswordChangeForm(request.user)
    context = {
        'form': form,
    }
    return render(request, 'accounts/password.html', context)
    
    
###### profile update ######### 
@login_required
def profile_update(request):
    profile = Profile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        profile_form = ProfileForm(request.POST, instance=request.user.profile)
        if profile_form.is_valid():
            profile_form.save()
            return redirect('people', request.user.username)
    else:
        profile_form = ProfileForm(instance=request.user.profile) # 유저의 프로필을 수정
    context = {'profile_form': profile_form,}
    
    return render(request,'accounts/profile_update.html', context)

################        follower        ###########################
@login_required
def follow(request, user_pk):
    people = get_object_or_404(get_user_model(), pk=user_pk)
    if request.user in people.followers.all():
        people.followers.remove(request.user)
    else:
        people.followers.add(request.user)
    return redirect('people', people.username)


################        like_movie        ###########################
@login_required
def follow_movie(request, user_pk):
    people = get_object_or_404(get_user_model(), pk=user_pk)
    if request.user in people.my_movies.all():
        people.my_movies.remove(request.user)
    else:
        people.my_movies.add(request.user)
    return redirect('movies:movie_detail', people.username)
    # movie_detail page에서 좋아요링크 구현해야할듯


################        like_genre        ###########################
# @login_required
# def my_genre(request, user_pk):
#     people = get_object_or_404(get_user_model(), pk=user_pk)
#     profile = get_object_or_404(Profile,user_id=user_pk)
#     # if request.user in people.my_genres.all():
#     #     people.my_genres.remove(request.user)
#     # else:
#     #     people.my_genres.add(request.user)
#     return redirect('#', people.username)
    # movie_detail page - genre(href로 이동) - genre 좋아요 누르기
    # 회원가입/ 비밀번호 수정 페이지에서도 바꿀 수 있게

    
    



    
    


    

