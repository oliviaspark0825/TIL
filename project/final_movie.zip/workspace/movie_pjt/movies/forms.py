from django import forms
from .models import Comment, Movie

class CommentForm(forms.ModelForm):
    content = forms.CharField(label="",)
    class Meta:
        model = Comment
        fields = ['content', 'score',]

# class ReviewForm(forms.ModelForm):
#     class Meta:
#         model = Movie
#         fields = ['review_score',]