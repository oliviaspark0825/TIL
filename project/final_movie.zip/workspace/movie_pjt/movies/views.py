import random
from django.shortcuts import render, redirect, get_list_or_404, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.views.decorators.http import require_POST
from django.db.models import Q
from .forms import CommentForm
from .models import Movie, Genre, Actor, Comment, Director
from accounts.models import User, Profile
from django.contrib.auth.models import AbstractUser

# Create your views here.
def list(request):
    ### 로그인 안한 유저
    movies = Movie.objects.all()
    movie = random.choice(movies)
    movie_picks = movies[:10]
    
    genres = Genre.objects.all()
    genre_pick = random.sample(range(1, 17), 3)
    
    genre_picks = []
    
    for genre in genre_pick:
        removies = Movie.objects.filter(genres__id=genre).order_by('pk')
        removie = random.choice(removies)
        genre_picks.append(removie)
        
    context = {
        'movies': movies,
        'movie': movie,
        'genres': genres,
        'movie_picks': movie_picks,
        'genre_picks': genre_picks,
    }
    return render(request, 'bueno/list.html', context)

def movie_list(request):
    movies = Movie.objects.all()
    genres = Genre.objects.all()

    context = {
        'movies': movies,
        'genres': genres,
    }
    return render(request, 'bueno/movies.html', context)

# 장르별 영화 정렬
def recommend_genre(request, genre_pk):
    movies = Movie.objects.filter(genres__id=genre_pk).order_by('pk')
    movie = random.choice(movies)
    pick = get_object_or_404(Genre, pk=genre_pk)
    context = {
        'movies': movies,
        'movie': movie,
        'pick': pick,
    }
    return render(request, 'bueno/recommend.html', context)

# 배우별 영화 정렬
def recommend_actor(request, actor_pk):
    movies = Movie.objects.filter(actors__id=actor_pk).order_by('pk')
    movie = random.choice(movies)
    pick = get_object_or_404(Actor, pk=actor_pk)
    context = {
        'movies': movies,
        'movie': movie,
        'pick': pick,
    }
    return render(request, 'bueno/recommend.html', context)
    

def like_director(request, movie_pk, director_pk,):
    director = get_object_or_404(Director, pk=director_pk)
    
    if director in request.user.profile.like_directors.all():
        request.user.profile.like_directors.remove(director)
    else:
        request.user.profile.like_directors.add(director)
    
    return redirect('movies:movie_detail', movie_pk)
    

def movie_detail(request, movie_pk):
    movie = get_object_or_404(Movie, pk=movie_pk)
    genres = Genre.objects.all()
    
    # people = get_object_or_404(get_user_model(), username=request.user.username)
    
    context = {
        'movie': movie,
        'genres': genres,
        'form': False,
        # 'people': people,
    }
    
    for comment in movie.comment_set.all():
        if request.user == comment.user:
            context['form'] = True
    
    return render(request, 'bueno/movie_detail.html', context)


############### comment ###################
@require_POST
@login_required
def comment_create(request, movie_pk):
    form = CommentForm(request.POST)
    movie = get_object_or_404(Movie, pk=movie_pk)
    
    if form.is_valid():
        comment = form.save(commit=False)
        comment.user = request.user
        comment.movie_id = movie_pk
        comment.save()
    return redirect('movies:movie_detail', movie_pk)

@login_required
def comment_update(request, movie_pk, comment_pk):
    comment = get_object_or_404(Comment, pk=comment_pk)
    movie = get_object_or_404(Movie, pk=movie_pk)
    
    if request.method == 'POST':
        form = CommentForm(request.POST, instance=comment)
        if form.is_valid():
            form.save()
            return redirect('movies:movie_detail', movie_pk)
    else:
        form = CommentForm(instance=comment)
    context = {
        'form': form,
        'movie': movie,
    }
    return render(request, 'bueno/comment.html', context)

@require_POST
@login_required
def comment_delete(request, movie_pk, comment_pk):
    comment = get_object_or_404(Comment, pk=comment_pk)
    movie = get_object_or_404(Movie, pk=movie_pk)
    
    if request.user != comment.user:
        return redirect('movies:list')

    comment.delete()
    return redirect('movies:movie_detail', movie_pk)
    
############### like ###################
# @login_required
# def movie_like(request, movie_pk):
#     movie = get_object_404(Movie, pk=movie_pk)
#     if request.user in movie