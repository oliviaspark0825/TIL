from django.urls import path
from . import views

app_name = 'movies'

urlpatterns = [
    path('<int:movie_pk>/director/<int:director_pk>/', views.like_director, name="like_director"),
    path('actor/<int:actor_pk>/', views.recommend_actor, name="recommend_actor"),
    path('genre/<int:genre_pk>/', views.recommend_genre, name="recommend_genre"),
    path('<int:movie_pk>/score/<int:comment_pk>/delete/', views.comment_delete, name="comment_delete"),
    path('<int:movie_pk>/score/<int:comment_pk>/', views.comment_update, name="comment_update"),
    path('<int:movie_pk>/score/', views.comment_create, name="comment_create"),
    path('<int:movie_pk>/', views.movie_detail, name="movie_detail"),
    path('browsing/', views.movie_list, name="movie_list"),
    path('', views.list, name="list"),
]