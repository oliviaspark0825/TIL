from django.shortcuts import render

# Create your views here.
student_list = {'박수현': 10, '강예원': 7, '신채원': 20 }

def info(request):
    Teacher = '김준호'
    return render(request, 'info.html', {'Teacher': Teacher, 'student_list': student_list})
    
def student(request, name):
    student_list = {'박수현': 10, '강예원': 7, '신채원': 20 }
    # for one in student_list.keys():
    #     if one == name:
    #         age = student_list[one]
    age = student_list.get(name, 'unknown')
    #none 값 대신에 수정방법
    teacher = {'address': '대전', 'name': '보라돌이', 'age': 30}
    
    
    return render(request, 'student.html',{'name': name, 'age': age, 'teacher': teacher})
    
    
    
