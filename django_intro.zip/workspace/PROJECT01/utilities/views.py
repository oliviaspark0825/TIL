from django.shortcuts import render
from datetime import datetime
import requests

# Create your views here.
def index(request):
    return render(request, 'utilities/index.html')
    
    
def bye(request):
    datetimenow = datetime.now()
    time2 = datetime(2019, 2, 28, 18, 00, 0)
    left =  time2 - datetimenow
    return render(request, 'utilities/bye.html',{'left': left })

def graduation(request):
    datetimenow = datetime.now()
    gradu = datetime(2019, 5, 28, 18, 00, 0)
    left_2 = gradu - datetimenow
    return render(request, 'utilities/graduation.html', {'left_2': left_2})

def imagepick(request):
    return render(request, 'utilities/imagepick.html')
    
def today(request):
    today = datetime.now()
    url= 'https://api.openweathermap.org/data/2.5/weather?q=Daejeon,kr&lang=kr&APPID=2cd6eb9d40b48654896ae272653a432a' 
    data = requests.get(url).json()
    today_weather = data['weather'][0]['description']
    temp_avg = round(data['main']['temp'] - 273.15)
    temp_max = round(data['main']['temp_max'] - 273.15)
    temp_min = round(data['main']['temp_min'] - 273.15)
    
    return render(request, 'utilities/today.html', 
    {'today': today, 'today_weather': today_weather,
        'temp_avg': temp_avg, 'temp_max': temp_max, 'temp_min': temp_min
    })
    
    
def ascii_new(request):
    
    return render(request, 'utilities/ascii_new.html')

def ascii_make(request):
    word = request.GET.get('word')
    # 리케스트에 있는 get메소드를 사용해서 데이터를 가지고오는 것
    font = request.GET.get('font')
    url =f'http://artii.herokuapp.com/make?text={word}&font={font}'
    data = requests.get(url).text
    # 리케스츠 모듈을 이용해서 데이터를
    #{} 안에 있어도 변수로 선언해주겠다
   
   
    return render(request, 'utilities/ascii_make.html', {'data': data})

def original(request):
    return render(request, 'utilities/original.html')

def translated(request):
    word = request.GET.get('word')
    naver_client_id = "kPpKyknlo_VY4mHtegGy"
    naver_client_secret = "AqgjlZ2BIT"
    
    papago_url = "https://openapi.naver.com/v1/papago/n2mt"
    # 네이버에 Post 요청을 위해서 필요한 내용들
    headers = {
        "X-Naver-Client-Id": naver_client_id,
        "X-Naver-Client-Secret": naver_client_secret
    }
    data = {
        "source": "ko",
        "target": "en",
        "text": text[4:]
    }
    papago_response = requests.post(papago_url, headers=headers, data=data).json()
    print(papago_response)
    reply_text = papago_response["message"]["result"]["translatedText"]
    
    return render(request, 'utilities/translated.html', {'word': word, 'reply_text' : reply_text})