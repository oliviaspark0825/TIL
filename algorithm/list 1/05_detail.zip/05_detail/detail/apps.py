from django.apps import AppConfig


class DetailConfig(AppConfig):
    name = 'detail'
