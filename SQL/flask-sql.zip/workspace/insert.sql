-- INSERT INTO classmate (name, age)
-- VALUES('홍길동', 223);

-- INSERT INTO classmate (id, name, age, address)
-- VALUES(2, '홍길동', 30, '서울');

--모든 열에 넣을때는 COLUMN명 안써도 됨
--INSERT INTO classmate
--VALUES(2, '홍길동', 30, '서울')

INSERT INTO classmate (name, age, address)
VALUES('안상현', 43, '대전');
INSERT INTO classmate (name, age, address)
VALUES('신채원', 15, '서울');

