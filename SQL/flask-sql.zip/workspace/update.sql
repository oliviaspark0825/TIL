-- UPDATE classmate
-- SET name='강예원', address='제주'
-- WHERE id=4;

UPDATE classmate
SET name='박성주', address='제주'
WHERE id=4 or id=6;